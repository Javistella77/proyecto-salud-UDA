<?php
session_start();
if (isset($_SESSION['usuario'])) {
  $usuario = $_SESSION['usuario'];
} else {
  header("Location: login.html");
  exit;
}

$mysqli = new mysqli("localhost", "root", "", "saludexpress");
if ($mysqli->connect_errno) {
  die("Error de conexión: " . $mysqli->connect_error);
}

$query = "SELECT * FROM medicos WHERE tipo_turno = 'virtual' AND estado = 'disponible'";
$resultado = $mysqli->query($query);
$medicos = $resultado->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Nuevo Turno</title>
  <link rel="stylesheet" href="Estilos/medic.css" />
</head>

<body>
  <script>
  window.addEventListener("scroll", function () {
    const nav = document.querySelector(".main-nav");
    if (window.scrollY > 50) {
      nav.classList.add("shrink");
    } else {
      nav.classList.remove("shrink");
    }
  });
</script>

    <!-- Barra Superior -->
    <div class="top-bar">
      <div class="top-bar-content">
        <span><img src="img/correo.png"class="icono"> correoelectronico@gmail.com</span>
        <span><img src="img/ubicacion.png" alt="Ubicación" class="icono"> Ubicación de la empresa</span>
        <span><img src="img/llamada-telefonica.png" alt="Teléfono" class="icono"> Teléfono</span>
      </div>
    </div>
    <nav class="main-nav">
      <div class="logo">
        <a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a>
      </div>
      <ul class="nav-links">
        <?php if (isset($_SESSION['usuario'])): ?>
          <li style="color:white; font-weight:bold; display:flex; align-items:center;">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?>
          </li>
          <li><a href="Perfil.php">Mi Perfil</a></li>
        <?php else: ?>
          <li><a id="Ingresar" href="login.html">Ingresar</a></li>
          <li><a id="Registrarme" href="login.html">Registrarme</a></li>
        <?php endif; ?>
        <li><a href="Contacto.php">Contacto</a></li>
      </ul>
    </nav>
<main class="main-content">
  <!--Menu-->
  <h1 style="text-align: center;color:#0b6e71">Médicos disponibles</h1>

  <div class="botones-navegacion" style="text-align: center;color:#0b6e71">
    <button onclick="paginaAnterior()">Anterior</button>
    <button onclick="paginaSiguiente()">Siguiente</button>
  </div>

  <div class="contenedor-medicos">

    <!--<pre><?php print_r($medicos); ?></pre> -->
    <?php foreach ($medicos as $medico): ?>
      <div class="tarjeta-medico">

        <h3><?= $medico['nombre'] . " " . $medico['apellido'] ?></h3>
        <p class="precio">$<?= number_format($medico['precio'], 0, ',', '.') ?> <span>/Pesos</span></p>
        <ul>

          <li>• Especialidad: <?= $medico['especialidad'] ?></li>
          <li>• Fecha: <?= $medico['fecha_disponible'] ?></li>
          <!--  <li>• Hora: <?= $medico['hora_disponible'] ?></li> -->

          <li>• Sede: <?= $medico['sede'] ?></li>

          <li class="Parpadeo"> 📞 Activo ahora</li>
        </ul>
         <button onclick="pagarTurno(
  '<?= $medico['nombre'] . " " . $medico['apellido'] ?>',
  <?= $medico['precio'] ?>,
  '<?= $medico['especialidad'] ?>',
  '<?= $medico['fecha_disponible'] ?>',
  '<?= $medico['hora_disponible'] ?? "10:00" ?>',
  '<?= $medico['sede'] ?>',
  '<?= $medico['tipo_turno'] ?>'
)">Pagar Turno</button>
      </div>
    <?php endforeach; ?>
  </div>
</main>
  <!--Footer-->
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-column">
        <h5>Email</h5>
        <p>Nombre@Nombre.com.ar</p>
        <p>Nombre@Nombre.com.ar</p>
      </div>
      <div class="footer-column">
        <h5>Teléfono</h5>
        <p>Línea Gratuita: 212202</p>
        <p>Teléfono Fijo: 2122021</p>
      </div>
      <div class="footer-column">
        <h5>Ubicación</h5>
        <p>Sede Central:</p>
        <p>Calle Siempreviva 123</p>
      </div>
      <div class="footer-column logo-redes">
        <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo" />
        <div class="redes-sociales">
          <a href="https://www.instagram.com/celedondaniel21/?next=%2F&hl=es-la"><img src="img/instagram.png" alt="Instagram" /></a>
          <a href="#"><img src="img/Facebook.png" alt="Facebook" /></a>
          <a href="#"><img src="img/linkedin.png" alt="LinkedIn" /></a>
        </div>
      </div>
    </div>
    <div class="footer-copy">
      © Copyright 2025. Todos los derechos reservados Nombre
    </div>
  </footer>

</body>

<script>

  function pagarTurno(nombre, precio, especialidad, fecha, hora, sede, tipo) {
    fetch('https://908a-191-82-32-154.ngrok-free.app/crear-preferencia-turno', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          nombre,
          precio,
          especialidad,
          fecha,
          hora,
          sede,
          tipo,
          email: "test@test.com" // Acá podés poner $_SESSION con PHP si querés
        })
      })
      .then(res => res.json())
      .then(data => {
        if (data.init_point) {
          window.location.href = data.init_point;
        } else {
          alert("No se pudo generar el pago.");
        }
      })
      .catch(err => {
        console.error(err);
        alert("Error al conectar con el servidor.");
      });
  }
</script>

</html>