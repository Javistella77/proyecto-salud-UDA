<?php

namespace MercadoPago\Resources\User;

/** Context class. */
class Context
{
    /** The user's IP address. */
    public ?string $ip_address;
}
