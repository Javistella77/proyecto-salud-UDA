<?php

/** API version: 7d364c51-04c7-45e3-af61-f82423bcc39c */

namespace MercadoPago\Resources\Order;

/** Payer class. */
class Payer
{
    /** Customer ID. */
    public ?string $customer_id;
}
