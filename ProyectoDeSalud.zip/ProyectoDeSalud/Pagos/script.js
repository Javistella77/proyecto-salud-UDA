document.getElementById("pagoForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const data = {
      titulo: formData.get("titulo"),
      precio: parseFloat(formData.get("precio"))
    };
  
    // Enviar los datos al backend (PHP)
    const response = await fetch("crear_preferencia.php", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json"
      }
    });
  
    const result = await response.json();
    
    // Verificar si se obtuvo el id de la preferencia
    if (result.id) {
      const mp = new MercadoPago('TEST-XXXXXXXXXXXXXXXXXXXXXXXX'); // Reemplazar con tu Public Key
      mp.checkout({
        preference: {
          id: result.id
        },
        render: {
          container: '#wallet_container',
          label: 'Pagar'
        }
      });
    } else {
      console.error('Error al crear la preferencia:', result.error);
    }
  });
  