<?php
require __DIR__ . '/Pagos/sdk-php-master/src/MercadoPago/autoload.php'; // Cargar clases necesarias

use MercadoPago\SDK;
use MercadoPago\Preference;
use MercadoPago\Item;

// Reemplazar con tu Access Token
SDK::setAccessToken('TEST-7666205984680119-041099-235180c013a4260c7646d8ce4966f584-1100697782');

// Obtener los datos JSON del frontend
$datos = json_decode(file_get_contents("php://input"), true);

// Verificar si los datos están completos
if (isset($datos["titulo"]) && isset($datos["precio"])) {
    // Crear el ítem
    $item = new Item();
    $item->title = $datos["titulo"];
    $item->quantity = 1;
    $item->unit_price = (float)$datos["precio"];

    // Crear la preferencia
    $preference = new Preference();
    $preference->items = [$item];
    $preference->save();

    // Enviar el id de la preferencia al frontend
    echo json_encode(["id" => $preference->id]);
} else {
    // Enviar un error si falta algún dato
    echo json_encode(["error" => "Faltan datos"]);
}
?>
