<?php 
$conexion = new mysqli("localhost", "root", "", "saludexpress");
if ($conexion->connect_error) {
    die("❌ Error de conexión: " . $conexion->connect_error);
} else {
    echo "✅ Conexión exitosa a la base de datos.";
}
$nombre = $_POST ["nombre"];
$apellido = $_POST ["apellido"];
$email = $_POST ["email"];
$documento = $_POST ["documento"];
$username = $_POST ["username"];
$contraseña = $_POST ["contraseña"];
$tipo_usuario = $_POST ["tipo_usuario"];

$sql = "INSERT INTO usuarios (nombre, apellido, email, documento, username, contraseña,planid, tipo_usuario)
VALUES ('$nombre', '$apellido', '$email', '$documento', '$username', '$contraseña',0, '$tipo_usuario')";

IF ($conexion->query($sql) === TRUE) {
    echo "Registro exitoso, redireccionando a la página de logueo...";
    echo '<meta http-equiv="refresh" content="3;url=login.html">';
} else {
    echo "Error: " . $sql . "<br>" . $conexion->error;
}

$conexion->close();
?>
