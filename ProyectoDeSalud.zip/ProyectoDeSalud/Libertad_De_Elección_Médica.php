<?php session_start(); ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Estilos/StyleLibertad.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
  <script>
  window.addEventListener("scroll", function () {
    const nav = document.querySelector(".main-nav");
    if (window.scrollY > 50) {
      nav.classList.add("shrink");
    } else {
      nav.classList.remove("shrink");
    }
  });
</script>

    <!-- Barra Superior -->
    <div class="top-bar">
      <div class="top-bar-content">
        <span><img src="img/correo.png"class="icono"> correoelectronico@gmail.com</span>
        <span><img src="img/ubicacion.png" alt="Ubicación" class="icono"> Ubicación de la empresa</span>
        <span><img src="img/llamada-telefonica.png" alt="Teléfono" class="icono"> Teléfono</span>
      </div>
    </div>
    <nav class="main-nav">
      <div class="logo">
        <a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a>
      </div>
      <ul class="nav-links">
        <?php if (isset($_SESSION['usuario'])): ?>
          <li style="color:white; font-weight:bold; display:flex; align-items:center;">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?>
          </li>
          <li><a href="Perfil.php">Mi Perfil</a></li>
        <?php else: ?>
          <li><a id="Ingresar" href="login.html">Ingresar</a></li>
          <li><a id="Registrarme" href="login.html">Registrarme</a></li>
        <?php endif; ?>
        <li><a href="Contacto.php">Contacto</a></li>
      </ul>
    </nav>
    <!-- Sección de Elección Médica -->
<main class="main-content">
<section class="eleccion-medica text-center py-5" style="font-family: tilt-neon-regular;">
    <div class="container">
      <h2 style="color: #3A8B8A;" class="fw-bold">Libertad de elección médica</h2>
      <p class="lead">Puedes elegir con quien te atenderás</p>
      <p class="text-info">Eligiendo la especialidad que desees</p>
      <div class="mb-4">
        <img src="img/elecciones.png" alt="Icono elección" class="img-fluid" style="max-width: 80px;">
      </div>
  
      <div class="row">
        <!-- Alejandro -->
        <div class="col-md-4 mb-4">
          <div class="card h-100 doctor-card" onclick="mostrarInfo('Alejandro')">
            <img src="imagenes/Alejandro.png" class="card-img-top" alt="Alejandro">
            <div class="card-body">
              <h5 class="card-title">Alejandro</h5>
              <p class="text-muted">Cardiología</p>
            </div>
          </div>
        </div>
  
        <!-- Sofía -->
        <div class="col-md-4 mb-4">
          <div class="card h-100 doctor-card" onclick="mostrarInfo('Sofía')">
            <img src="imagenes/Sofia.png" class="card-img-top" alt="Sofía">
            <div class="card-body">
              <h5 class="card-title">Sofía</h5>
              <p class="text-muted">Neumonología</p>
            </div>
          </div>
        </div>
  
        <!-- Leonel -->
        <div class="col-md-4 mb-4">
          <div class="card h-100 doctor-card" onclick="mostrarInfo('Leonel')">
            <img src="imagenes/Leonel.png" class="card-img-top" alt="Leonel">
            <div class="card-body">
              <h5 class="card-title">Leonel</h5>
              <p class="text-muted">Oftalmología</p>
            </div>
          </div>
        </div>
  
        <!-- Antonella -->
        <div class="col-md-4 mb-4">
          <div class="card h-100 doctor-card" onclick="mostrarInfo('Antonella')">
            <img src="imagenes/Antonella.png" class="card-img-top" alt="Antonella">
            <div class="card-body">
              <h5 class="card-title">Antonella</h5>
              <p class="text-muted">Psicología</p>
            </div>
          </div>
        </div>
  
        <!-- Julio -->
        <div class="col-md-4 mb-4">
          <div class="card h-100 doctor-card" onclick="mostrarInfo('Julio')">
            <img src="imagenes/Julio.png" class="card-img-top" alt="Julio">
            <div class="card-body">
              <h5 class="card-title">Julio</h5>
              <p class="text-muted">Médico Clínico</p>
            </div>
          </div>
        </div>
  
        <!-- Martina -->
        <div class="col-md-4 mb-4">
          <div class="card h-100 doctor-card" onclick="mostrarInfo('Martina')">
            <img src="imagenes/Martina.png" class="card-img-top" alt="Martina">
            <div class="card-body">
              <h5 class="card-title">Martina</h5>
              <p class="text-muted">Traumatología</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  
    <!-- Overlay con info del doctor -->
    <div class="overlay" id="overlay">
      <div class="doctor-info-box" id="infoBox">
        <span class="close-btn" onclick="cerrarInfo()">&times;</span>
        <h4 id="nombreDoctor">Dr. Nombre</h4>
        <p id="especialidadDoctor">Especialidad</p>
        <p id="edadDoctor">Edad: --</p>
        <p id="experienciaDoctor">Experiencia: --</p>
        <a href="Especialidad.php" style="text-decoration: none;color: white;"><button class="btn-turno">Sacar turno</button></a>
      </div>
    </div>
  </section>
  
</main>
</body>
<!--jAVASCRIPT-->
<script>
    const infoDoctores = {
      Alejandro: {
        nombre: "Dr. Alejandro",
        especialidad: "Cardiólogo",
        edad: "45 años",
        experiencia: "20 años de experiencia"
      },
      Sofía: {
        nombre: "Dra. Sofía",
        especialidad: "Neumonóloga",
        edad: "39 años",
        experiencia: "15 años de experiencia"
      },
      Leonel: {
        nombre: "Dr. Leonel",
        especialidad: "Oftalmólogo",
        edad: "50 años",
        experiencia: "25 años de experiencia"
      },
      Antonella: {
        nombre: "Dra. Antonella",
        especialidad: "Psicóloga",
        edad: "32 años",
        experiencia: "7 años de experiencia"
      },
      Julio: {
        nombre: "Dr. Julio",
        especialidad: "Médico Clínico",
        edad: "60 años",
        experiencia: "35 años de experiencia"
      },
      Martina: {
        nombre: "Dra. Martina",
        especialidad: "Traumatóloga",
        edad: "41 años",
        experiencia: "18 años de experiencia"
      }
    };
  
    function mostrarInfo(nombre) {
      const datos = infoDoctores[nombre];
      if (datos) {
        document.getElementById("nombreDoctor").innerText = datos.nombre;
        document.getElementById("especialidadDoctor").innerText = datos.especialidad;
        document.getElementById("edadDoctor").innerText = `Edad: ${datos.edad}`;
        document.getElementById("experienciaDoctor").innerText = `Experiencia: ${datos.experiencia}`;
      }
      document.getElementById("overlay").style.display = "flex";
    }
  
    function cerrarInfo() {
      document.getElementById("overlay").style.display = "none";
    }
  </script>
<!----------FOOTER------------->  
<footer class="footer">
    <div class="footer-container">
        <div class="footer-column">
            <h5>Email</h5>
            <p>Nombre@Nombre.com.ar</p>
            <p>Nombre@Nombre.com.ar</p>
        </div>
        <div class="footer-column">
            <h5>Teléfono</h5>
            <p>Línea Gratuita: 212202</p>
            <p>Teléfono Fijo: 2122021</p>
        </div>
        <div class="footer-column">
            <h5>Ubicación</h5>
            <p>Sede Central:</p>
            <p>Calle Siempreviva 123</p>
        </div>
        <div class="footer-column logo-redes">
            <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo">
            <div class="redes-sociales">
                <!-- Acá van tus íconos -->
                <a href="https://www.instagram.com/celedondaniel21/?next=%2F&hl=es-la"><img src="img/instagram.png" alt="Instagram"></a>
                <a href="#"><img src="img/Facebook.png" alt="Facebook"></a>
                <a href="#"><img src="img/linkedin.png" alt="LinkedIn"></a>
            </div>
        </div>
    </div>
    <div class="footer-copy">
        © Copyright 2025. Todos los derechos reservados Nombre
    </div>
  </footer>
  
  </html>