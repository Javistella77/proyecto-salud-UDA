<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Nuevo Turno</title>
  <link rel="stylesheet" href="Estilos/turnosnuev.css">
  
</head>
<body>
  <script>
  window.addEventListener("scroll", function () {
    const nav = document.querySelector(".main-nav");
    if (window.scrollY > 50) {
      nav.classList.add("shrink");
    } else {
      nav.classList.remove("shrink");
    }
  });
</script>

    <!-- Barra Superior -->
    <div class="top-bar">
      <div class="top-bar-content">
        <span><img src="img/correo.png"class="icono"> correoelectronico@gmail.com</span>
        <span><img src="img/ubicacion.png" alt="Ubicación" class="icono"> Ubicación de la empresa</span>
        <span><img src="img/llamada-telefonica.png" alt="Teléfono" class="icono"> Teléfono</span>
      </div>
    </div>
    <nav class="main-nav">
      <div class="logo">
        <a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a>
      </div>
      <ul class="nav-links">
        <?php if (isset($_SESSION['usuario'])): ?>
          <li style="color:white; font-weight:bold; display:flex; align-items:center;">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?>
          </li>
          <li><a href="Perfil.php">Mi Perfil</a></li>
        <?php else: ?>
          <li><a id="Ingresar" href="login.html">Ingresar</a></li>
          <li><a id="Registrarme" href="login.html">Registrarme</a></li>
        <?php endif; ?>
        <li><a href="Contacto.php">Contacto</a></li>
      </ul>
    </nav>
<main class="main-content">
  <!--Inicio-->
  <h1>Nuevo Turno</h1>

  <div class="contenedor-turno">
    <label>Especialidad seleccionada:</label>
    <div class="especialidad">Cardiología</div>

    <label for="fecha">Fecha del turno:</label>
    <input type="date" id="fecha" name="fecha">

    <label for="hora">Hora del turno:</label>
    <input type="time" id="hora" name="hora">

    <label for="sede">Sede:</label>
    <select id="sede" name="sede">
      <option value="central">Sede Central</option>
      <option value="norte">Sede Norte</option>
      <option value="sur">Sede Sur</option>
    </select>

    <button onclick="confirmarTurno()"><a href="Medicos.php" style="text-decoration: none;color: white;">Confirmar Turno</a></button>
  </div>
</main>
  <!--Footer-->
  <footer class="footer">
    <div class="footer-container">
        <div class="footer-column">
            <h5>Email</h5>
            <p>Nombre@Nombre.com.ar</p>
            <p>Nombre@Nombre.com.ar</p>
        </div>
        <div class="footer-column">
            <h5>Teléfono</h5>
            <p>Línea Gratuita: 212202</p>
            <p>Teléfono Fijo: 2122021</p>
        </div>
        <div class="footer-column">
            <h5>Ubicación</h5>
            <p>Sede Central:</p>
            <p>Calle Siempreviva 123</p>
        </div>
        <div class="footer-column logo-redes">
            <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo">
            <div class="redes-sociales">
                <a href="https://www.instagram.com/celedondaniel21/?next=%2F&hl=es-la"><img src="img/instagram.png" alt="Instagram"></a>
                <a href="#"><img src="img/Facebook.png" alt="Facebook"></a>
                <a href="#"><img src="img/linkedin.png" alt="LinkedIn"></a>
            </div>
        </div>
    </div>
    <div class="footer-copy">
        © Copyright 2025. Todos los derechos reservados Nombre
    </div>
  </footer>
  <script>
    function confirmarTurno() {
      const fecha = document.getElementById("fecha").value;
      const hora = document.getElementById("hora").value;
      const sede = document.getElementById("sede").value;

      if (!fecha || !hora) {
        alert("Por favor, complete todos los campos.");
        return;
      }

      alert(`Turno confirmado:\nFecha: ${fecha}\nHora: ${hora}\nSede: ${sede}`);
    }
  </script>
</body>
</html>
<style>
  /*parte principal*/
h1 {
        color: #006666;
        margin-top: 20px;
        font-size: 2.5rem;
        text-align: center;
        top: 10px;
        position: relative;
      }
  
      .icono {
        font-size: 50px;
        margin-top: 20px;
      }
  
      .contenedor-turno {
        max-width: 400px;
        margin: 30px auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
        background-color: white;
        text-align: left;
      }
  
      label {
        display: block;
        margin-top: 15px;
        font-weight: bold;
        color: #333;
      }
  
      input, select {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        border-radius: 6px;
        border: 1px solid #ccc;
        font-size: 1rem;
      }
  
      .especialidad {
        color: #006666;
        font-weight: bold;
        margin-top: 5px;
        background-color: #f1f1f1;
        padding: 10px;
        border-radius: 6px;
      }
  
      button {
        width: 100%;
        margin-top: 20px;
        padding: 12px;
        background-color: #006666;
        color: white;
        font-size: 1rem;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.3s;
      }
  
      button:hover {
        background-color: #004d4d;
      }
</style>