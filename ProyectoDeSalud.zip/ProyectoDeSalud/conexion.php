<?php
$server="localhost";
$user="root";
$pass="";
$db="saludexpress";

$conexion = mysqli_connect($server, $user, $pass, $db);

if (!$conexion) { 
    die("No hay conexion: ".mysqli_connect_error()); 
}
?>