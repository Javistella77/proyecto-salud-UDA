require('dotenv').config();

const express = require('express');
const axios = require('axios');
const path = require('path');
const cors = require('cors');
const mysql = require('mysql2/promise');

const app = express();
app.use(cors());
app.use(express.json());

// Carga la URL base de ngrok desde .env
const NGROK_URL = process.env.NGROK_URL;

// Configuración de la base de datos
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'saludexpress'
};

// PLANES 
app.post('/crear-preferencia', async (req, res) => {
  const { plan_id, email } = req.body;

  try {
    const connection = await mysql.createConnection(dbConfig);
    const [rows] = await connection.execute(
      'SELECT descripcion, precio FROM planes WHERE planid = ?',
      [plan_id]
    );
    await connection.end();

    if (rows.length === 0) {
      return res.status(404).send("Plan no encontrado");
    }

    const plan = rows[0];

    const response = await axios.post(
      'https://api.mercadopago.com/checkout/preferences',
      {
        items: [
          {
            title: `Plan ${plan.descripcion}`,
            quantity: 1,
            unit_price: parseFloat(plan.precio),
            currency_id: "ARS"
          }
        ],
        back_urls: {
          success: `${NGROK_URL}/Pruebadepago.html`,
          failure: `${NGROK_URL}/failure`,
          pending: `${NGROK_URL}/pending`
        },
        auto_return: "approved",
        payer: { email: email },
        external_reference: `${email}|${plan_id}`
      },
      {
        headers: {
          'Authorization': `Bearer TEST-5434109927623404-050812-2c7bda8edbb40f886815ded172f0b888-248925698`,
          'Content-Type': 'application/json'
        }
      }
    );

    res.json({ init_point: response.data.init_point });

  } catch (error) {
    console.error("Error al crear la preferencia: ", error.response?.data || error.message);
    res.status(500).send("Error al crear la preferencia de pago");
  }
});

// Confirmar pago y actualizar plan desde Mercado Pago
app.get('/confirmar-pago', async (req, res) => {
  const { collection_id } = req.query;

  if (!collection_id) return res.status(400).json({ error: 'Falta collection_id' });

  try {
    const mpResponse = await axios.get(
      `https://api.mercadopago.com/v1/payments/${collection_id}`,
      {
        headers: {
          Authorization: 'Bearer TEST-5434109927623404-050812-2c7bda8edbb40f886815ded172f0b888-248925698'
        }
      }
    );

    const payment = mpResponse.data;
    const externalReference = payment.external_reference;

    if (!externalReference) return res.status(400).json({ error: 'No hay external_reference' });

    const [email, plan_id] = externalReference.split('|');

    const connection = await mysql.createConnection(dbConfig);
    const [result] = await connection.execute('UPDATE usuarios SET planid = ? WHERE email = ?', [plan_id, email]);
    await connection.end();

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Usuario no encontrado para actualizar" });
    }

    console.log(`Plan actualizado automáticamente para ${email} a plan ${plan_id}`);
    res.json({ mensaje: 'Plan actualizado correctamente' });

  } catch (error) {
    console.error("Error al confirmar pago y actualizar plan:", error.response?.data || error.message);
    res.status(500).json({ error: 'Error al confirmar pago y actualizar plan' });
  }
});

// Actualizar plan manualmente desde botón en Pruebadepago.html
app.post('/actualizar-plan', async (req, res) => {
  const { plan_id, email } = req.body;

  if (!plan_id || !email) {
    return res.status(400).json({ success: false, message: "Faltan parámetros (plan_id o email)" });
  }

  try {
    const connection = await mysql.createConnection(dbConfig);
    const [result] = await connection.execute(
      'UPDATE usuarios SET planid = ? WHERE email = ?',
      [plan_id, email]
    );
    await connection.end();

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: "Usuario no encontrado o no actualizado" });
    }

    console.log(`Plan actualizado manualmente para ${email} a plan ${plan_id}`);
    res.json({ success: true, message: "Plan actualizado correctamente" });

  } catch (error) {
    console.error(" Error al actualizar el plan manualmente:", error.message);
    res.status(500).json({ success: false, message: "Error interno al actualizar el plan" });
  }
});

// ---------- TURNOS ----------

// Crear preferencia de pago para turno
app.post('/crear-preferencia-turno', async (req, res) => {
  const { nombre, precio, especialidad, fecha, hora, sede, tipo, email } = req.body;

  let successUrl;
  if (tipo === 'virtual') {
    successUrl = `${NGROK_URL}/PagoConfirmado.html?nombre=${encodeURIComponent(nombre)}&fecha=${fecha}&hora=${hora}&sede=${sede}&email=${email}`;
  } else {
    successUrl = `${NGROK_URL}/ticket.html?nombre=${encodeURIComponent(nombre)}&fecha=${fecha}&hora=${hora}&sede=${sede}&email=${email}`;
  }

  try {
    const response = await axios.post(
      'https://api.mercadopago.com/checkout/preferences',
      {
        items: [
          {
            title: `Turno ${tipo} - ${especialidad} con ${nombre}`,
            quantity: 1,
            unit_price: parseFloat(precio),
            currency_id: "ARS"
          }
        ],
        back_urls: {
          success: successUrl,
          failure: `${NGROK_URL}/failure`,
          pending: `${NGROK_URL}/pending`
        },
        auto_return: "approved",
        payer: { email: email }
      },
      {
        headers: {
          Authorization: 'Bearer TEST-5434109927623404-050812-2c7bda8edbb40f886815ded172f0b888-248925698',
          'Content-Type': 'application/json'
        }
      }
    );

    res.json({ init_point: response.data.init_point });

  } catch (error) {
    console.error("Error al generar el pago del turno:", error.response?.data || error.message);
    res.status(500).send("No se pudo generar el pago");
  }
});

// Confirmar turno luego del pago
app.post('/confirmar-turno', async (req, res) => {
  const { nombre, especialidad, fecha, hora, sede, tipo, email } = req.body;

  if (!nombre || !especialidad || !fecha || !hora || !sede || !tipo || !email) {
    return res.status(400).json({ error: "Faltan parámetros para guardar el turno" });
  }

  try {
    const connection = await mysql.createConnection(dbConfig);
    const sql = `
      INSERT INTO turnos (nombre, especialidad, fecha, hora, sede, tipo, email)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    await connection.execute(sql, [nombre, especialidad, fecha, hora, sede, tipo, email]);
    await connection.end();

    console.log(` Turno registrado: ${nombre}, ${fecha} ${hora}, ${tipo} en ${sede}`);
    res.json({ mensaje: "Turno confirmado correctamente" });

  } catch (error) {
    console.error("Error al registrar el turno:", error.message);
    res.status(500).json({ error: "Error interno al guardar el turno" });
  }
});

// ---------- STATIC FILES ----------
app.use(express.static(path.join(__dirname, 'public')));

// ---------- SERVER ----------
app.listen(3000, () => console.log('Server corriendo en el puerto 3000'));
