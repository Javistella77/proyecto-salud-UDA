<?php
session_start();
$conexion = new mysqli("localhost", "root", "", "saludexpress");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$email = $_POST["email"];
$contraseña = $_POST["contraseña"]; 

// Consulta segura con prepared statements (más seguro)
$stmt = $conexion->prepare("SELECT * FROM usuarios WHERE email = ? AND contraseña = ? AND disponible = 1");
$stmt->bind_param("ss", $email, $contraseña);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado && $resultado->num_rows == 1) {
    $usuario = $resultado->fetch_assoc();

    // Guardamos en sesión los datos necesarios
    $_SESSION['usuarioid'] = $usuario['id'];
    $_SESSION['usuario'] = $usuario['username'];
    $_SESSION['tipo_usuario'] = strtolower($usuario['tipo_usuario']); // ✅ CORREGIDO

    header("Location: Perfil.php"); // o inicio.php según tu sistema
    exit();
} else {
    echo "<script>alert('Usuario o contraseña incorrectos o no disponible'); window.location.href='login.html';</script>";
    exit();
}
?>
