<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    echo "No estás logueado.";
    exit;
}

$mysqli = new mysqli("localhost", "root", "", "saludexpress");
if ($mysqli->connect_errno) {
    die("Error de conexión: " . $mysqli->connect_error);
}

$resultado = $mysqli->query("SELECT planid AS id, descripcion, precio FROM planes WHERE planid <> 0");
$planes = $resultado->fetch_all(MYSQLI_ASSOC);

// Clases CSS para los planes según planid
$clases = [
    1 => 'bronce',
    2 => 'plata',
    3 => 'oro',
    4 => 'diamante',
    5 => 'black'
];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Planes</title>
    <link rel="stylesheet" href="Estilos/planess.css" />
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
    <script src="bootstrap/js/bootstrap.js"></script>
    <style>
        .tarjeta {
            border-radius: 10px;
            padding: 20px;
            color: white;
            font-family: Arial, sans-serif;
            margin-bottom: 10px;
            cursor: pointer;
        }
        .tarjeta.bronce { background-color: #cd7f32; }
        .tarjeta.plata { background-color: #c0c0c0; color: black; }
        .tarjeta.oro { background-color: #ffd700; color: black; }
        .tarjeta.diamante { background-color: #b9f2ff; color: black; }
        .tarjeta.black { background-color: #000000; }

        .plan.selected {
            border: 3px solid #218380;
            box-shadow: 0 0 10px #218380;
        }

        .plan {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
  <script>
  window.addEventListener("scroll", function () {
    const nav = document.querySelector(".main-nav");
    if (window.scrollY > 50) {
      nav.classList.add("shrink");
    } else {
      nav.classList.remove("shrink");
    }
  });
</script>

    <!-- Barra Superior -->
    <div class="top-bar">
      <div class="top-bar-content">
        <span><img src="img/correo.png"class="icono"> correoelectronico@gmail.com</span>
        <span><img src="img/ubicacion.png" alt="Ubicación" class="icono"> Ubicación de la empresa</span>
        <span><img src="img/llamada-telefonica.png" alt="Teléfono" class="icono"> Teléfono</span>
      </div>
    </div>
    <nav class="main-nav">
      <div class="logo">
        <a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a>
      </div>
      <ul class="nav-links">
        <?php if (isset($_SESSION['usuario'])): ?>
          <li style="color:white; font-weight:bold; display:flex; align-items:center;">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?>
          </li>
          <li><a href="Perfil.php">Mi Perfil</a></li>
        <?php else: ?>
          <li><a id="Ingresar" href="login.html">Ingresar</a></li>
          <li><a id="Registrarme" href="login.html">Registrarme</a></li>
        <?php endif; ?>
        <li><a href="Contacto.php">Contacto</a></li>
      </ul>
    </nav>
    <!-- Contenido de los Planes -->
    <main class="main-content">
        <h1 style="color: #218380;">Planes</h1>

        <div class="planes-container">
            <?php foreach ($planes as $plan): ?>
            <div class="plan" onclick="seleccionar(this, <?= $plan['id'] ?>, '<?= htmlspecialchars($plan['descripcion'], ENT_QUOTES) ?>')">
                <div class="tarjeta <?= isset($clases[$plan['id']]) ? $clases[$plan['id']] : '' ?>">
                    <div>1234 5678 8976 5432</div>
                    <div>12/23</div>
                    <div>SUSAN SMITH</div>
                </div>
                <div class="descripcion">
                    <h3>Plan <?= htmlspecialchars($plan['descripcion']) ?></h3>
                    <p><?= htmlspecialchars($plan['descripcion']) ?></p>
                    <p><strong>Precio:</strong> $<?= number_format($plan['precio'], 0, ',', '.') ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

     <form id="formularioCompra">            
    <input type="hidden" name="plan_id" id="plan_id">
    <input type="hidden" name="plan_nombre" id="plan_nombre">
    <button type="button" class="btn-comprar" onclick="irAMercadoPago()">Comprar</button>
</form>
    </main>

    <!-- FOOTER -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-column">
                <h5>Email</h5>
                <p>Nombre@Nombre.com.ar</p>
                <p>Nombre@Nombre.com.ar</p>
            </div>
            <div class="footer-column">
                <h5>Teléfono</h5>
                <p>Línea Gratuita: 212202</p>
                <p>Teléfono Fijo: 2122021</p>
            </div>
            <div class="footer-column">
                <h5>Ubicación</h5>
                <p>Sede Central:</p>
                <p>Calle Siempreviva 123</p>
            </div>
            <div class="footer-column logo-redes">
                <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo">
                <div class="redes-sociales">
                    <a href="#"><img src="img/instagram.png" alt="Instagram"></a>
                    <a href="#"><img src="img/Facebook.png" alt="Facebook"></a>
                    <a href="#"><img src="img/linkedin.png" alt="LinkedIn"></a>
                </div>
            </div>
        </div>
        <div class="footer-copy">
            © Copyright 2025. Todos los derechos reservados Nombre
        </div>
    </footer>

    <script>
    const emailUsuario = "<?php echo $_SESSION['usuario']; ?>";

    let planSeleccionado = null;

    function seleccionar(elemento, planId, nombrePlan) {
        document.querySelectorAll('.plan').forEach(p => p.classList.remove('selected'));
        elemento.classList.add('selected');
        document.getElementById('plan_id').value = planId;
        document.getElementById('plan_nombre').value = nombrePlan;
        planSeleccionado = nombrePlan;
    }

    async function irAMercadoPago() {
    if (!planSeleccionado) {
        alert('Por favor seleccioná un plan antes de comprar.');
        return;
    }

    const planId = document.getElementById('plan_id').value;

    // Guardamos en localStorage
    localStorage.setItem('plan_id', planId);
    localStorage.setItem('email', emailUsuario);

    try {
        const response = await fetch('https://908a-191-82-32-154.ngrok-free.app/crear-preferencia', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                plan_id: planId,
                email: emailUsuario
            })
        });

        const data = await response.json();
        if (data && data.init_point) {
            window.location.href = data.init_point;
        } else {
            alert('Error al iniciar el pago');
        }
    } catch (error) {
        alert('Error en la conexión con Mercado Pago');
        console.error(error);
    }
}
</script>
</body>
</html>