<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <style>
        @font-face {
            font-family: sensai;
            src: url(fuentes/sensai.otf);
        }
        body{
            background-attachment: fixed;
            background-position: center;
            background-size: cover;
            background-image:url("gifs/ciudad destruida.gif");
            background-repeat: no-repeat;
            color: white;
        }
        h1{
            font-size: 300%;
            font-family: sensai;
            -webkit-text-stroke: 2px rgb(255, 0, 0 );
        }
        p a{
            text-decoration: none;
            color: #fff;
            font-family: sensai;
            font-size: 300%;
            -webkit-text-stroke: 2px rgb(47, 0, 255);
        }
    </style>
</head>
<body>
    <h1>No sos Bienvenido 7_7</h1>
    <p><a href="index.php">Volver al Login</a></p>
    <img src="gifs/snoop.gif" alt="">
</body>
</html>