<?php
// ticket.php

session_start();
//if (!isset($_SESSION['medico_id'])) {
  //  echo "No estás autenticado.";
    //exit;
//}

$medico_id = $_SESSION['medico_id'];

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "nombre_de_tu_base_de_datos");
if ($conexion->connect_error) {
    die("Error en la conexión: " . $conexion->connect_error);
}

// Obtener los datos del médico
$sql = "SELECT nombre, apellido, especialidad, matricula FROM medicos WHERE id = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $medico_id);
$stmt->execute();
$stmt->bind_result($nombre, $apellido, $especialidad, $matricula);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Receta médica</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 40px;
            max-width: 800px;
            margin: auto;
        }
        .encabezado {
            text-align: center;
            border-bottom: 2px solid black;
            margin-bottom: 20px;
        }
        .encabezado img {
            height: 80px;
        }
        .datos-medico, .datos-paciente, .receta {
            margin-bottom: 20px;
        }
        .datos-medico b, .datos-paciente b {
            display: inline-block;
            width: 120px;
        }
        .receta {
            padding: 10px;
            border: 1px solid #ccc;
            min-height: 100px;
        }
        .firma {
            text-align: right;
            margin-top: 40px;
        }
    </style>
</head>
<body>

<div class="encabezado">
    <img src="logo.png" alt="Logo de la clínica">
    <h2>Receta Médica</h2>
</div>

<div class="datos-medico">
    <p><b>Médico:</b> <?= $nombre . " " . $apellido ?></p>
    <p><b>Especialidad:</b> <?= $especialidad ?></p>
    <p><b>Matrícula:</b> <?= $matricula ?></p>
</div>

<div class="datos-paciente">
    <p><b>Paciente:</b> Juan Pérez</p>
    <p><b>Fecha:</b> <?= date("d/m/Y") ?></p>
</div>

<div class="receta">
    <p>Tomar 1 comprimido de Paracetamol 500mg cada 8 horas por 3 días.</p>
</div>

<div class="firma">
    ___________________________<br>
    Firma y sello
</div>

</body>
</html>
