<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">    
</head>
<body>
    <div class="Caja">
        <div class="for">
            <h1>Iniciar Sesion</h1>
                <form method="POST" action="login.php">
                    <img src="gifs/itachi.gif" alt=""style="position: absolute;width: 80px;top:235px;left:55px;height:80px;">
                    <label class="usu">USUARIO</label><br>
                    <input class="usu" type="text" placeholder="Escriba su Usuario" name="usuario" required><br>

                    <label class="con">CONTRASEÑA</label><br>
                    <input class="con" type="password" placeholder="Escriba su Contraseña" name="contraseña" required><br>
                    <a class="registrarme" href="registro.php">Registrarme</a>
                    <input class="boton"type="submit" value="Ingresar">
                     <?php
                        if (isset($_GET['registro_exitoso']) && $_GET['registro_exitoso'] == 1) {
                            echo "<p style='color: green;'>Registro exitoso. Ahora puedes iniciar sesión.</p>";
                        }
                    ?>
                </form>
        </div>
    </div>
</body>
</html>