<?php 
session_start();

$conexion = new mysqli("localhost", "root", "", "saludexpress");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$nueva_contraseña = $_POST["nueva_contraseña"];
$email = $_SESSION['email'];

$sql = "UPDATE usuarios SET contraseña = '$nueva_contraseña' WHERE email = '$email'";

if ($conexion->query($sql) === TRUE) {
    echo "<script>alert('Contraseña actualizada con éxito'); window.location.href='login.html';</script>";
} else {
    echo "Error al actualizar: " . $conexion->error;
}
?>




