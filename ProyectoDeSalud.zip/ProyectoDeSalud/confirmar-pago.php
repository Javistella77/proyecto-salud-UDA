<?php
session_start();

header('Content-Type: application/json');

// 1. Verificamos que el usuario esté logueado
if (!isset($_SESSION['usuarioid'])) {
    echo json_encode(['success' => false, 'error' => 'No estás logueado']);
    exit();
}

// 2. Verificamos que nos llegó el collection_id de Mercado Pago
if (!isset($_GET['collection_id'])) {
    echo json_encode(['success' => false, 'error' => 'No se recibió el ID de la transacción']);
    exit();
}

$usuarioid = $_SESSION['usuarioid'];
$collection_id = $_GET['collection_id'];

// 3. Conectamos a la base de datos
$conexion = new mysqli("localhost", "root", "", "saludexpress");
if ($conexion->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Error de conexión a la base de datos']);
    exit();
}

// 4. Aquí idealmente validarías el pago con Mercado Pago, pero para este ejemplo vamos a suponer que el pago fue OK

// 5. Actualizamos el plan del usuario en la base de datos
// Cambia el valor 2 por el plan que quieras asignar
$nuevoPlanId = 2;

$query = "UPDATE usuarios SET planid = ? WHERE id = ?";
$stmt = $conexion->prepare($query);
$stmt->bind_param("ii", $nuevoPlanId, $usuarioid);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'No se pudo actualizar el plan']);
}

$stmt->close();
$conexion->close();
