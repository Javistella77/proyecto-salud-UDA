<?php
session_start();
header('Content-Type: application/json');

// if (!isset($_SESSION['usuario'])) {
//     echo json_encode(['success' => false, 'message' => 'No estás logueado.']);
//     exit;
// }

$data = json_decode(file_get_contents('php://input'), true);



if (!$data || !isset($data['plan_id']) || !isset($data['email'])) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos.']);
    exit;
}

$planId = (int)$data['plan_id'];
$email = $data['email'];

$mysqli = new mysqli("localhost", "root", "", "saludexpress");

if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos.']);
    exit;
}

$stmt = $mysqli->prepare("SELECT id FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Usuario no encontrado.']);
    exit;
}

$usuario = $result->fetch_assoc();
$usuarioId = (int)$usuario['id'];

$stmt = $mysqli->prepare("UPDATE usuarios SET planid = ? WHERE id = ?");
$stmt->bind_param("ii", $planId, $usuarioId);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al actualizar el plan.']);
}
