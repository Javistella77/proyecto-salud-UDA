<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Prueba de Pago</title>
  <link rel="stylesheet" href="../Estilos/reg.css" />
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
<body style="margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-image: url('WhatsApp Image 2025-04-07 at 00.18.08.jpeg'); background-size: cover; background-position: center; background-repeat: no-repeat;">
  <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh; backdrop-filter: blur(10px); padding: 20px;">
    <div style="background-color: rgba(255, 255, 255, 0.1); border: 2px solid rgba(20, 20, 20, 0.3); border-radius: 20px; padding: 40px; text-align: center; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2); backdrop-filter: blur(15px);">
      
      <h1 style="color: #ffffff; font-size: 32px; margin-bottom: 10px;">💳 Compra realizada con exito!! Ir a confirmación </h1>
      
      <a href="ActualizacionPlan.php"><button id="btnActualizarPlan" style="padding: 12px 24px; font-size: 16px; color: white; background: linear-gradient(135deg, #3ab393, #3ab393); border: none; border-radius: 8px; cursor: pointer; transition: transform 0.2s ease, background 0.3s ease;">
        Confirmar Compra
      </button>
      </a>
    </div>
  </div>

  <script>
        document.getElementById('btnActualizarPlan').addEventListener('click', () => {
            const planId = 3; 
            const email = 'jstella@vadigu.com'; 

            const payload = {
                plan_id: planId,
                email: email
            };

            console.log('Enviando payload:', payload);

            fetch('ActualizarPlan.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include', 
                body: JSON.stringify(payload)
            })
            .then(response => {
                const contentType = response.headers.get("content-type");
                if (!contentType || !contentType.includes("application/json")) {
                    throw new Error("La respuesta no es JSON válida");
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    alert(' Plan actualizado correctamente. Te redirigimos al perfil...');
                    window.location.href = '../perfil.php'; 
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error en la petición:', error);
                //alert('Error en la petición: ' + error.message);
            });
        });
    </script>

  
</body>

</html>