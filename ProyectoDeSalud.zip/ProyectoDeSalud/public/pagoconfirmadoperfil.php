<?php session_start(); ?>
<?php 
  $email = isset($_SESSION['email']) ? $_SESSION['email'] : 'jstella@vadigu.com'; // reemplazar si tenés el email en session
?>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Pago Confirmado</title>
  <link rel="stylesheet" href=".../Estilos/pago.css">
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>

  <!-- Barra Superior -->
  <div class="top-bar">
    <div class="top-bar-content">
      <span><img src="img/correo.png" class="icono"> correoelectronico@gmail.com</span>
      <span><img src="img/ubicacion.png" class="icono"> Ubicación de la empresa</span>
      <span><img src="img/llamada-telefonica.png" class="icono"> Teléfono</span>
    </div>
  </div>

  <!-- Navegación -->
  <nav class="main-nav">
    <div class="logo">
      <a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a>
    </div>
    <ul class="nav-links">
      <?php if (isset($_SESSION['usuario'])): ?>
        <li style="color:white; font-weight:bold; display:flex; align-items:center;">
          Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?>
        </li>
        <li><a href="Perfil.php">Mi Perfil</a></li>
      <?php else: ?>
        <li><a id="Ingresar" href="login.html">Ingresar</a></li>
        <li><a id="Registrarme" href="login.html">Registrarme</a></li>
      <?php endif; ?>
      <li><a href="Contacto.php">Contacto</a></li>
    </ul>
  </nav>

  <!-- Contenido Principal -->
  <main class="main-content">
    <img src="img/Confirmado.jpeg" alt="Pago Confirmado" class="iconos">
    <h1 style="color: #218380;">Pago Confirmado</h1>
    <p style="text-align: center;" class="texto">¡Pago confirmado con éxito! Ahora podés ingresar a tu perfil para consultar los detalles del plan que adquiriste.</p>

    <!-- Botón que ejecuta la lógica -->
    <button id="btnActualizarPlan" class="boton">Mi Perfil</button>
  </main>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-column">
        <h5>Email</h5>
        <p>Nombre@Nombre.com.ar</p>
        <p>Nombre@Nombre.com.ar</p>
      </div>
      <div class="footer-column">
        <h5>Teléfono</h5>
        <p>Línea Gratuita: 212202</p>
        <p>Teléfono Fijo: 2122021</p>
      </div>
      <div class="footer-column">
        <h5>Ubicación</h5>
        <p>Sede Central:</p>
        <p>Calle Siempreviva 123</p>
      </div>
      <div class="footer-column logo-redes">
        <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo">
        <div class="redes-sociales">
          <a href="https://www.instagram.com/celedondaniel21/?next=%2F&hl=es-la"><img src="img/instagram.png" alt="Instagram"></a>
          <a href="#"><img src="img/Facebook.png" alt="Facebook"></a>
          <a href="#"><img src="img/linkedin.png" alt="LinkedIn"></a>
        </div>
      </div>
    </div>
    <div class="footer-copy">
      © Copyright 2025. Todos los derechos reservados Nombre
    </div>
  </footer>

  <!-- Script para actualizar el plan -->
  <script>
    document.getElementById('btnActualizarPlan').addEventListener('click', () => {
      const planId = 3; // ID del plan a asignar (Bronce, Plata, Oro, etc.)
      const email = "<?php echo $email; ?>"; // Email desde PHP

      const payload = {
        plan_id: planId,
        email: email
      };

      console.log('Enviando payload:', payload);

      fetch('ActualizarPlan.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(payload)
      })
      .then(response => {
        const contentType = response.headers.get("content-type");
        if (!contentType || !contentType.includes("application/json")) {
          throw new Error("La respuesta no es JSON válida");
        }
        return response.json();
      })
      .then(data => {
        if (data.success) {
          alert('✅ Plan actualizado correctamente. Redirigiendo al perfil...');
          window.location.href = 'Perfil.php';
        } else {
          alert('❌ Error: ' + data.message);
        }
      })
      .catch(error => {
        console.error('Error en la petición:', error);
        alert('❌ Error en la petición: ' + error.message);
      });
    });
  </script>

</body>
</html>
