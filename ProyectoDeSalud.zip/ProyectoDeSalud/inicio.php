<?php session_start(); ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Estilos/style.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
  <script>
  window.addEventListener("scroll", function () {
    const nav = document.querySelector(".main-nav");
    if (window.scrollY > 50) {
      nav.classList.add("shrink");
    } else {
      nav.classList.remove("shrink");
    }
  });
</script>

    <!-- Barra Superior -->
    <div class="top-bar">
      <div class="top-bar-content">
        <span><img src="img/correo.png"class="icono"> correoelectronico@gmail.com</span>
        <span><img src="img/ubicacion.png" alt="Ubicación" class="icono"> Ubicación de la empresa</span>
        <span><img src="img/llamada-telefonica.png" alt="Teléfono" class="icono"> Teléfono</span>
      </div>
    </div>
    <nav class="main-nav">
      <div class="logo">
        <a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a>
      </div>
      <ul class="nav-links">
        <?php if (isset($_SESSION['usuario'])): ?>
          <li style="color:white; font-weight:bold; display:flex; align-items:center;">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?>
          </li>
          <li><a href="Perfil.php">Mi Perfil</a></li>
        <?php else: ?>
          <li><a id="Ingresar" href="login.html">Ingresar</a></li>
          <li><a id="Registrarme" href="login.html">Registrarme</a></li>
        <?php endif; ?>
        <li><a href="Contacto.php">Contacto</a></li>
      </ul>
    </nav>
<main class="main-content">
    <!--Inicio-->
    <div class="botones">
 <?php
$tipo_usuario = isset($_SESSION['tipo_usuario']) ? strtolower($_SESSION['tipo_usuario']) : '';

if ($tipo_usuario === 'medico'):
?>
  <!-- SOLO TURNOS para médicos -->
  <div class="boton" style="background-color: #FFBC42">
    <a href="TipoTurno.php" style="text-decoration: none;color: white;">Turnos</a>
  </div>
<?php else: ?>
  <!-- OTROS BOTONES para pacientes o admins -->
  <div class="boton" style="background-color: #FFBC42">
    <a href="TipoTurno.php" style="text-decoration: none;color: white;">Turnos</a>
  </div>
  <div class="boton" style="background-color: #73D2DE;">
    <a href="Planes.php" style="text-decoration: none;color: white;">Planes</a>
  </div>
  <div class="boton" style="background-color: #218380;">
    <a href="Beneficios.php" style="text-decoration: none;color: white;">Beneficios</a>
  </div>
  <div class="boton" style="background-color: #D81159;">
    <a href="urgencias.php" style="text-decoration: none;color: white;">Urgencias</a>
  </div>
<?php endif; ?>
    </div>  
 <?php
$tipo_usuario = isset($_SESSION['tipo_usuario']) ? strtolower($_SESSION['tipo_usuario']) : '';

if ($tipo_usuario === 'medico'):
?>
<main class="main-content">
        <!--Slide-->
        <div id="carouselExample" class="carousel slide">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="imagenes/Imagen de Doctor 1.jpg" class="d-block w-100" alt="..." style="object-fit: cover;display: block; width: 90%;height: 500px;border-radius: 10px;">
            </div>
            <div class="carousel-item">
              <img src="imagenes/Imagen de Doctor 2.jpg" class="d-block w-100" alt="..." style="object-fit: cover;display: block;width: 90%;height: 500px;border-radius: 10px;">
            </div>
            <div class="carousel-item">
              <img src="imagenes/Imagen de Doctor 3.jpg" class="d-block w-100" alt="..." style="object-fit: cover;display: block;width: 90%;height: 500px;border-radius: 10px;">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
        <!-- Centros de salud (imagen izquierda) -->
  <div class="d-flex mb-5">
    <div class="card custom-card card-left">
    <div class="row g-0 align-items-center flex-md-row">
      <div class="col-md-6">
        <img src="imagenes/Empresa con nuestro logo.png" class="img-fluid w-100 h-100 object-fit-cover" alt="...">
      </div>
      <div class="col-md-6 text-end p-4">
        <p class="text-muted mb-1">Conocé</p>
        <h5 class="fw-bold text-teal">LOS CENTROS DE SALUD <span class="text-secondary">más cercanos.</span></h5>
        <button class="btn custom-btn mt-3" id="consultar"><a href="Centro de salud.php" style="text-decoration: none;color: white;">Consultar</a></button>
      </div>
    </div>
  </div>
</div>
</main>
<?php else: ?>

    <main class="main-content">
        <!--Slide-->
        <div id="carouselExample" class="carousel slide">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="imagenes/Imagen de Doctor 1.jpg" class="d-block w-100" alt="..." style="object-fit: cover;display: block; width: 90%;height: 500px;border-radius: 10px;">
            </div>
            <div class="carousel-item">
              <img src="imagenes/Imagen de Doctor 2.jpg" class="d-block w-100" alt="..." style="object-fit: cover;display: block;width: 90%;height: 500px;border-radius: 10px;">
            </div>
            <div class="carousel-item">
              <img src="imagenes/Imagen de Doctor 3.jpg" class="d-block w-100" alt="..." style="object-fit: cover;display: block;width: 90%;height: 500px;border-radius: 10px;">
            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
          </button>
        </div>
     <!-- Elección libre de médico-->
     <div class="d-flex mb-5">
      <div class="card custom-card card-left">
        <div class="row g-0 align-items-center flex-md-row">
          <div class="col-md-6">
            <img src="imagenes/Imagen de Doctor 1.jpg" class="img-fluid w-100 h-100 object-fit-cover" alt="...">
          </div>
          <div class="col-md-6 text-end p-4">
            <p class="text-muted mb-1">Servicios</p>
            <h5 class="fw-bold text-teal">ELECCIÓN LIBRE DE MÉDICO</h5>
            <a href="Libertad_De_Elección_Médica.php" style="text-decoration: none;color: white;"><button class="btn custom-btn mt-3" id="consultar">Consultar</button></a>
          </div>
        </div>
      </div>
</div>

  <!-- Atención online 24hs-->
  <div class="d-flex mb-5">
    <div class="card custom-card card-right">
      <div class="row g-0 align-items-center flex-md-row-reverse">
        <div class="col-md-6">
          <img src="imagenes/Manos Con Computadora.png" class="img-fluid w-100 h-100 object-fit-cover" alt="...">
        </div>
        <div class="col-md-6 text-end p-4">
          <p class="text-muted mb-1">Visitá a tu médico</p>
          <h5 class="fw-bold text-teal">ONLINE, LAS 24HS<br><span class="text-secondary">SIN COSTO adicional.</span></h5>
          <button class="btn custom-btn mt-3" id="consultar"><a href="servicio24hs.php"style="text-decoration: none;color: white;">Consultar</a></button>
        </div>
      </div>
    </div>
  </div>
         <!-- Centros de salud (imagen izquierda) -->
  <div class="d-flex mb-5">
    <div class="card custom-card card-left">
    <div class="row g-0 align-items-center flex-md-row">
      <div class="col-md-6">
        <img src="imagenes/Empresa con nuestro logo.png" class="img-fluid w-100 h-100 object-fit-cover" alt="...">
      </div>
      <div class="col-md-6 text-end p-4">
        <p class="text-muted mb-1">Conocé</p>
        <h5 class="fw-bold text-teal">LOS CENTROS DE SALUD <span class="text-secondary">más cercanos.</span></h5>
        <button class="btn custom-btn mt-3" id="consultar"><a href="Centro de salud.php" style="text-decoration: none;color: white;">Consultar</a></button>
      </div>
    </div>
  </div>
</div>
</main>
<?php endif; ?>

<footer class="footer">
  <div class="footer-container">
      <div class="footer-column">
          <h5>Email</h5>
          <p>Nombre@Nombre.com.ar</p>
          <p>Nombre@Nombre.com.ar</p>
      </div>
      <div class="footer-column">
          <h5>Teléfono</h5>
          <p>Línea Gratuita: 212202</p>
          <p>Teléfono Fijo: 2122021</p>
      </div>
      <div class="footer-column">
          <h5>Ubicación</h5>
          <p>Sede Central:</p>
          <p>Calle Siempreviva 123</p>
      </div>
      <div class="footer-column logo-redes">
          <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo">
          <div class="redes-sociales">
              <!-- Acá van tus íconos -->
              <a href="https://www.instagram.com/celedondaniel21/?next=%2F&hl=es-la"><img src="img/instagram.png" alt="Instagram"></a>
              <a href="#"><img src="img/Facebook.png" alt="Facebook"></a>
              <a href="#"><img src="img/linkedin.png" alt="LinkedIn"></a>
          </div>
      </div>
  </div>
  <div class="footer-copy">
      © Copyright 2025. Todos los derechos reservados Nombre
  </div>
</footer>
</body>
</html>