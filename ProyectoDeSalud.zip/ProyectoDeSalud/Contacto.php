<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contacto</title>
  <link rel="stylesheet" href="Estilos/stylecontacto.css" />
  <script defer src="script.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
  <script>
  window.addEventListener("scroll", function () {
    const nav = document.querySelector(".main-nav");
    if (window.scrollY > 50) {
      nav.classList.add("shrink");
    } else {
      nav.classList.remove("shrink");
    }
  });
</script>

    <!-- Barra Superior -->
    <div class="top-bar">
      <div class="top-bar-content">
        <span><img src="img/correo.png"class="icono"> correoelectronico@gmail.com</span>
        <span><img src="img/ubicacion.png" alt="Ubicación" class="icono"> Ubicación de la empresa</span>
        <span><img src="img/llamada-telefonica.png" alt="Teléfono" class="icono"> Teléfono</span>
      </div>
    </div>
    <nav class="main-nav">
      <div class="logo">
        <a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a>
      </div>
      <ul class="nav-links">
        <?php if (isset($_SESSION['usuario'])): ?>
          <li style="color:white; font-weight:bold; display:flex; align-items:center;">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?>
          </li>
          <li><a href="Perfil.php">Mi Perfil</a></li>
        <?php else: ?>
          <li><a id="Ingresar" href="login.html">Ingresar</a></li>
          <li><a id="Registrarme" href="login.html">Registrarme</a></li>
        <?php endif; ?>
        <li><a href="Contacto.php">Contacto</a></li>
      </ul>
    </nav>
<main class="main-content">
  <section class="contacto">
    <h2><i class="fas fa-mobile-alt"></i> Contacto</h2>

    <div class="contenido">
      <div class="mapa">
        <!-- API Google Maps embebida -->
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3358.7068132043263!2d-68.8458262!3d-32.8894499!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x967e091d6f814e7b%3A0x6a3b6c1d2aaf4506!2sCentro%20de%20Salud!5e0!3m2!1ses!2sar!4v1612891234567" 
          width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy">
        </iframe>
      </div>

      <div class="info">
        <p><i class="fas fa-phone-alt"></i> 261 40502123<br><span>Lunes a Viernes (9am–17pm)</span></p>
        <p><i class="fas fa-envelope"></i> atencionalafiliado@Nombre.com.ar<br><a href="http://www.nombre.com.ar">www.nombre.com.ar</a></p>
        <p><i class="fas fa-map-marker-alt"></i> Mariano Moreno 170<br>Ciudad de Mendoza, ARG</p>
      </div>
    </div>
  </section>
</main>
  <script>
    // Por si quieres hacer pop-ups, validaciones o efectos JS
    console.log("Sección de contacto cargada correctamente.");
  </script>
  <!----------FOOTER------------->  
<footer class="footer">
    <div class="footer-container">
        <div class="footer-column">
            <h5>Email</h5>
            <p>Nombre@Nombre.com.ar</p>
            <p>Nombre@Nombre.com.ar</p>
        </div>
        <div class="footer-column">
            <h5>Teléfono</h5>
            <p>Línea Gratuita: 212202</p>
            <p>Teléfono Fijo: 2122021</p>
        </div>
        <div class="footer-column">
            <h5>Ubicación</h5>
            <p>Sede Central:</p>
            <p>Calle Siempreviva 123</p>
        </div>
        <div class="footer-column logo-redes">
            <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo">
            <div class="redes-sociales">
                <!-- Acá van tus íconos -->
                <a href="https://www.instagram.com/celedondaniel21/?next=%2F&hl=es-la"><img src="img/instagram.png" alt="Instagram"></a>
                <a href="#"><img src="img/Facebook.png" alt="Facebook"></a>
                <a href="#"><img src="img/linkedin.png" alt="LinkedIn"></a>
            </div>
        </div>
    </div>
    <div class="footer-copy">
        © Copyright 2025. Todos los derechos reservados Nombre
    </div>
  </footer>
  
</body>

</html>
