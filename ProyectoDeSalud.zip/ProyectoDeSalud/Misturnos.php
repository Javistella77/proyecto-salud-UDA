<?php session_start(); ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Estilos/inicio.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
  <script>
  window.addEventListener("scroll", function () {
    const nav = document.querySelector(".main-nav");
    if (window.scrollY > 50) {
      nav.classList.add("shrink");
    } else {
      nav.classList.remove("shrink");
    }
  });
</script>

    <!-- Barra Superior -->
    <div class="top-bar">
      <div class="top-bar-content">
        <span><img src="img/correo.png"class="icono"> correoelectronico@gmail.com</span>
        <span><img src="img/ubicacion.png" alt="Ubicación" class="icono"> Ubicación de la empresa</span>
        <span><img src="img/llamada-telefonica.png" alt="Teléfono" class="icono"> Teléfono</span>
      </div>
    </div>
    <nav class="main-nav">
      <div class="logo">
        <a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a>
      </div>
      <ul class="nav-links">
        <?php if (isset($_SESSION['usuario'])): ?>
          <li style="color:white; font-weight:bold; display:flex; align-items:center;">
            Bienvenido, <?php echo htmlspecialchars($_SESSION['usuario']); ?>
          </li>
          <li><a href="Perfil.php">Mi Perfil</a></li>
        <?php else: ?>
          <li><a id="Ingresar" href="login.html">Ingresar</a></li>
          <li><a id="Registrarme" href="login.html">Registrarme</a></li>
        <?php endif; ?>
        <li><a href="Contacto.php">Contacto</a></li>
      </ul>
    </nav>
    <style>
        @font-face {
    font-family: tilt-neon-regular;
    src: url(Estilos/tilt-neon-regular.ttf);
  }
  body{
    font-family: tilt-neon-regular;
  }
  /* Reset de márgenes y padding */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body{
  font-family: tilt-neon-regular;
}
/* Barra superior fija */
.top-bar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background-color: #A2D6D3;
  padding: 10px 0;
  z-index: 1100;
}
.top-bar-content {
    display: flex;
    justify-content: center;
    gap: 40px;
    font-size: 14px;
    align-items: center;
    flex-wrap: wrap;
    color: #ffffff; /* Corregido el color */
}

.top-bar-content span {
    display: flex;
    align-items: center;
    gap: 8px;
}

.icono {
    width: 16px;
    height: 16px;
}

/* Barra de navegación fija + animación */
.main-nav {
  font-family: tilt-neon-regular;
  position: fixed;
  top: 40px;
  left: 0;
  width: 100%;
  background-color: #3f8b89;
  z-index: 1000;
  padding: 20px 40px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  transition: padding 0.3s, background-color 0.3s, box-shadow 0.3s;
  box-shadow: none;
}

.main-nav .logo img {
  height: 80px;
  width: 150px;
  transition: height 0.3s, width 0.3s;
}

.main-nav.shrink {
  padding: 5px 30px;
  background-color: #246f6c;
  box-shadow: 0 2px 10px rgba(0,0,0,0.15);
}

.main-nav.shrink .logo img {
  height: 50px;
  width: 100px;
}


.main-nav .nav-links {
    list-style: none;
    display: flex;
    gap: 30px;
    margin: 0;
    padding: 0;
}

.main-nav .nav-links li a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    transition: color 0.3s;
}

.main-nav .nav-links li a:hover {
    color: #CBEDEB;
}

/* Agrega esto al inicio de tu contenido principal para evitar que quede oculto */
.main-content {
    margin-top: 140px; /* Suma la altura de .top-bar y .main-nav */
}
/*Contenido de la web TipoTurno */


        .container {
             font-family: tilt-neon-regular;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%; /* Ocupa todo el ancho disponible */
            max-width: 500px;
        }

        h1 {
            color:#3f8b89;
            font-family: tilt-neon-regular;
            margin-bottom: 20px;
            font-size: 1.8em; /* Ajuste para mejor legibilidad */
        }

        .appointments-box {
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 5px;
            min-height: 150px;
            max-height: 300px;
            overflow-y: auto; /* Permite desplazamiento si hay muchos turnos */
            text-align: left;
            margin-bottom: 20px;
            background-color: #fcfcfc;
        }

        .appointment-item {
            padding: 10px 0;
            border-bottom: 1px dashed #eee;
            font-size: 1.1em;
            color: #555;
        }

        .appointment-item:last-child {
            border-bottom: none; /* Elimina la línea divisoria del último turno */
        }

        button {
            background-color: #008080;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease; /* Transición suave al pasar el mouse */
        }

        button:hover {
            background-color:rgb(2, 52, 52);
        }

        /* Responsive adjustments */
        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }
            h1 {
                font-size: 1.5em;
            }
            button {
                width: 100%; /* Botón ocupa todo el ancho en pantallas pequeñas */
            }
        }
        /*Footer*/
.footer {
    background-color: #3b8d92;
    color: white;
    padding: 30px 10px 10px;
    font-family: tilt-neon-regular;
    font-size: 14px;
}

.footer-container {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    text-align: left;
    gap: 20px;
}

.footer-column {
    min-width: 200px;
}

.footer-column h5 {
    font-weight: bold;
    margin-bottom: 10px;
}

.footer-logo {
    width: 100px;
    margin-bottom: 10px;
}

.redes-sociales a img {
    width: 30px;
    margin-right: 10px;
}

.footer-copy {
    text-align: center;
    margin-top: 20px;
    color: #ccc;
}
    </style>
<<main class="main-content">
    <div class="container">
        <h1>Mis Turnos Asignados</h1>
        <div class="appointments-box" id="appointmentsBox">
            <p>Cargando turnos...</p>
        </div>
        <button onclick="location.reload()">Refrescar Turnos</button>
    </div>
</main>
<footer class="footer">
  <div class="footer-container">
      <div class="footer-column">
          <h5>Email</h5>
          <p>Nombre@Nombre.com.ar</p>
          <p>Nombre@Nombre.com.ar</p>
      </div>
      <div class="footer-column">
          <h5>Teléfono</h5>
          <p>Línea Gratuita: 212202</p>
          <p>Teléfono Fijo: 2122021</p>
      </div>
      <div class="footer-column">
          <h5>Ubicación</h5>
          <p>Sede Central:</p>
          <p>Calle Siempreviva 123</p>
      </div>
      <div class="footer-column logo-redes">
          <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo">
          <div class="redes-sociales">
              <!-- Acá van tus íconos -->
              <a href="https://www.instagram.com/celedondaniel21/?next=%2F&hl=es-la"><img src="img/instagram.png" alt="Instagram"></a>
              <a href="#"><img src="img/Facebook.png" alt="Facebook"></a>
              <a href="#"><img src="img/linkedin.png" alt="LinkedIn"></a>
          </div>
      </div>
  </div>
  <div class="footer-copy">
      © Copyright 2025. Todos los derechos reservados Nombre
  </div>
</footer>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const appointmentsBox = document.getElementById('appointmentsBox');

            function getRandomNumber(min, max) {
                return Math.floor(Math.random() * (max - min + 1)) + min;
            }

            function generateRandomDate() {
                const today = new Date();
                const futureDays = getRandomNumber(1, 30); // Turnos en los próximos 1 a 30 días
                const randomDate = new Date(today);
                randomDate.setDate(today.getDate() + futureDays);

                const year = randomDate.getFullYear();
                const month = (randomDate.getMonth() + 1).toString().padStart(2, '0'); // Meses son 0-11
                const day = randomDate.getDate().toString().padStart(2, '0');

                return `${day}/${month}`;
            }

            function generateRandomTime() {
                const hour = getRandomNumber(9, 18); // Horas entre 9 AM y 6 PM
                const minute = getRandomNumber(0, 1) * 30; // 00 o 30 minutos
                return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')} horas`;
            }

            function generateAppointments() {
                appointmentsBox.innerHTML = ''; // Limpiar turnos existentes

                const numberOfAppointments = getRandomNumber(1, 5); // Entre 1 y 5 turnos aleatorios

                if (numberOfAppointments === 0) {
                    appointmentsBox.innerHTML = '<p>No tienes turnos asignados por el momento.</p>';
                    return;
                }

                for (let i = 0; i < numberOfAppointments; i++) {
                    const date = generateRandomDate();
                    const time = generateRandomTime();
                    const appointmentDiv = document.createElement('div');
                    appointmentDiv.classList.add('appointment-item');
                    appointmentDiv.textContent = `Turno para el ${date} a las ${time}`;
                    appointmentsBox.appendChild(appointmentDiv);
                }
            }

            // Generar turnos cuando la página carga
            generateAppointments();
        });
    </script>
</body>
</html>