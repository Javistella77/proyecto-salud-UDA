<?php
session_start();

$mysqli = new mysqli("localhost", "root", "", "saludexpress");
if ($mysqli->connect_errno) {
  die("Error de conexión a la base de datos.");
}

$username = $_POST['username'];
$password = $_POST['password'];

$query = "SELECT * FROM usuarios WHERE username = ? AND disponible = 1 AND EsAdmin = 1";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();
  if ($password === $user['contraseña']) {
    $_SESSION['admin_username'] = $username;
    header("Location: admin_panel.php");
    exit;
  } else {
    echo "Contraseña incorrecta.";
  }
} else {
  echo "Acceso denegado. Usuario no válido o no autorizado.";
}
?>