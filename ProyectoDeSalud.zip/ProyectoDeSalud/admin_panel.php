<?php
session_start();
if (!isset($_SESSION['admin_username'])) {
    die("Acceso denegado.");
}

$mysqli = new mysqli("localhost", "root", "", "saludexpress");
if ($mysqli->connect_errno) {
    die("Error de conexión a la base de datos.");
}

if (isset($_POST['crear'])) {
    $username = $_POST['new_username'];
   $password = $_POST['new_password'];

    $email = $_POST['new_email'];
    $nombre = $_POST['new_nombre'];
    $apellido = $_POST['new_apellido'];
    $documento = $_POST['new_documento'];

    $query = "INSERT INTO usuarios (username, contraseña, email, nombre, apellido, documento, disponible, EsAdmin) VALUES (?, ?, ?, ?, ?, ?, 1, 0)";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("sssssi", $username, $password, $email, $nombre, $apellido, $documento);
    $stmt->execute();
    echo "<p class='mensaje'>Usuario creado correctamente.</p>";
}

if (isset($_POST['editar'])) {
    $username = $_POST['edit_username'];
    $nuevo_email = $_POST['edit_email'];
    $Disponible = $_POST['edit_disponible'];
    $nueva_contra = $_POST['edit_password']; // SIN hash como pediste

    // Validar si el usuario existe
    $verificar = $mysqli->prepare("SELECT * FROM usuarios WHERE username = ?");
    $verificar->bind_param("s", $username);
    $verificar->execute();
    $resultado = $verificar->get_result();

    if ($resultado->num_rows > 0) {
        // Existe: actualizamos
        $query = "UPDATE usuarios SET email = ?, contraseña = ?, Disponible = ? WHERE username = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ssss", $nuevo_email, $nueva_contra, $Disponible, $username);
        $stmt->execute();
        echo "<p class='mensaje'>Usuario editado correctamente.</p>";
    } else {
        // No existe
        echo "<p class='mensaje'>El usuario '$username' no existe.</p>";
    }
}

if (isset($_POST['eliminar'])) {
    $username = $_POST['delete_username'];
    $query = "DELETE FROM usuarios WHERE username = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    echo "<p class='mensaje'>Usuario eliminado correctamente.</p>";
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Panel Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Montserrat', sans-serif;
            background-image: url('imagenes/WhatsApp Image 2025-04-07 at 00.18.08.jpeg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            padding: 40px 20px;
            backdrop-filter: blur(8px);
        }

        .panel {
            background-color: rgba(3, 3, 3, 0.12);
            border: 2px solid rgba(23, 22, 22, 0.2);
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(20px);
            color: white;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .section {
            margin-bottom: 20px;
        }

        .section h3 {
            cursor: pointer;
            background-color: rgba(255, 255, 255, 0.15);
            padding: 10px;
            border-radius: 10px;
            margin: 0;
        }

        .content {
            display: none;
            margin-top: 10px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px 0;
            border: none;
            border-radius: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .mensaje {
            background-color: #28a745aa;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            color: white;
            margin-top: 15px;
        }

        form label {
            font-weight: 600;
        }
    </style>
    <script>
        function toggle(id) {
            const e = document.getElementById(id);
            e.style.display = e.style.display === 'block' ? 'none' : 'block';
        }
    </script>
</head>

<body>
    <div class="panel">
        <h2>Bienvenido, Admin: <?php echo htmlspecialchars($_SESSION['admin_username']); ?></h2>

        <div class="section">
            <h3 onclick="toggle('crear')">▶ Crear usuario</h3>
            <div id="crear" class="content">
                <form method="post">
                    <input type="hidden" name="crear" value="1">
                    <label>Username:</label>
                    <input type="text" name="new_username" required>
                    <label>Contraseña:</label>
                    <input type="password" name="new_password" required>
                    <label>Email:</label>
                    <input type="email" name="new_email" required>
                    <label>Nombre:</label>
                    <input type="text" name="new_nombre" required>
                    <label>Apellido:</label>
                    <input type="text" name="new_apellido" required>
                     <label>Documento:</label>
                    <input type="text" name="new_documento" required>
                    <input type="submit" value="Crear">
                   
                </form>
            </div>
        </div>

        <div class="section">
            <h3 onclick="toggle('editar')">▶ Editar usuario</h3>
            <div id="editar" class="content">
                <form method="post">
                    <input type="hidden" name="editar" value="1">
                    <label>Username a editar:</label>
                    <input type="text" name="edit_username" required>
                    <label>Nuevo Email:</label>
                    <input type="email" name="edit_email" required>
                    <label>Disponible (1/0):</label>
                    <input type="text" name="edit_disponible" required>
                    <label>Nueva Contraseña:</label>
                    <input type="password" name="edit_password" required>
                    <input type="submit" value="Editar">
                </form>
            </div>
        </div>

        <div class="section">
            <h3 onclick="toggle('eliminar')">▶ Eliminar usuario</h3>
            <div id="eliminar" class="content">
                <form method="post">
                    <input type="hidden" name="eliminar" value="1">
                    <label>Username a eliminar:</label>
                    <input type="text" name="delete_username" required>
                    <input type="submit" value="Eliminar">
                </form>
            </div>
        </div>

        <div class="section">
            <h3 onclick="toggle('salir')">▶ Cerrar sesión</h3>
            <div id="salir" class="content">
                <form action="logout2.php" method="post">
                    <input type="submit" value="Salir">
                </form>
            </div>
        </div>
    </div>
</body>

</html>