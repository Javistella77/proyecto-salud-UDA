<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>nueva_contraseña</title>
  <link rel="stylesheet" href="Estilos/reg.css" />
<head>
<body style="background-image: url('imagenes/FondoLogin.jpeg');">
    <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh;">
    <div style="background-color: rgba(5, 5, 5, 0.2); border: 2px solid white; border-radius: 10px; padding: 30px; backdrop-filter: blur(30px);">
 <div class="Recovery">
    <h2 style="color: white;">Escribe tu nueva contraseña</h2>
 </div>
  <form action="actualizar_contraseña.php" method="POST">
  <div class="container-input">
      <ion-icon name="person-circle-outline"></ion-icon>
      <input type="password" name="nueva_contraseña" placeholder="Nueva contraseña" required/>
    </div>
    <button class="button">Actualizar</button>
  </form>
  </div>
</body>

</html>


