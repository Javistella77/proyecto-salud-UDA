const container = document.getElementById('main-container');
const btnSignUp = document.getElementById('btn-sign-up');
const btnSignIn = document.getElementById('btn-sign-in');

btnSignUp.addEventListener('click', () => {
  container.classList.add("right-panel-active");
});

btnSignIn.addEventListener('click', () => {
  container.classList.remove("right-panel-active");
});