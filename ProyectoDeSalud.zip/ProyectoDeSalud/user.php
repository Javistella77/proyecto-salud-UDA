<?php
include 'conexion.php';

$usuarioid = 3;

$query = " SELECT 
            u.nombre,
            u.apellido,
            u.documento,
            u.email,
            p.descripcion
            from usuarios u
            join planes p on u.planid = p.planid
            where u.id = $usuarioid";


$resultado = mysqli_query($conexion, $query);

$usuario = mysqli_fetch_assoc($resultado); //convierte el resultado en un array 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Perfil</title>
</head>
<body>
    <h2>Perfil</h2>
    <p><strong>Nombre:</strong> <?php echo $usuario['nombre']; ?></p>
    <p><strong>Apellido:</strong> <?php echo $usuario['apellido']; ?></p>
    <p><strong>DNI:</strong> <?php echo $usuario['documento']; ?></p>
    <p><strong>Email:</strong> <?php echo $usuario['email']; ?></p>
    <p><strong>Plan:</strong> <?php echo $usuario['descripcion']; ?></p> 
</body>
</html>