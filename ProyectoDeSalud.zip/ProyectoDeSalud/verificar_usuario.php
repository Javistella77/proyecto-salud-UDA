<?php
session_start();
$conexion = new mysqli("localhost", "root", "", "saludexpress");

$email = $_POST["email"];
$username = $_POST["username"];

$sql = "SELECT * FROM usuarios WHERE email = '$email' AND username = '$username' AND disponible = 1"; 
$resultado = $conexion->query($sql);

if ($resultado && $resultado->num_rows == 1) {
    $_SESSION['email'] = $email;
    header("Location: nueva_contraseña.php");
} else {
    echo "<script>alert('Usuario no encontrado'); window.location.href='recuperar.php';</script>";
}
?>
