<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Registro.css">
    <title>Registro</title>
</head>
<body>
    <?php
        include("conexion.php");
        include("control_registro.php");
    ?>
    <div class="Caja">
        <style>
            @font-face {
                font-family: Gun;
                src: url(fuentes/Gun.ttf);
            }
            .imagen{
                position: absolute;
                size: cover;
                width: 100%;
                z-index: 1;
            }
        </style>
    <form action="" method="post" class="cajita">
        <fieldset>
            <legend style="font-family:Gun;-webkit-text-stroke: 1px rgb(47, 0, 255);">REGISTRO</legend>        
            <label style="font-family:Gun;-webkit-text-stroke: 1px #fff; color:black;font-size:90%">NOMBRE</label><br>
            <input type="text" name="nombre" placeholder="Escriba su Nombre" required><br>

            <label style="font-family:Gun;-webkit-text-stroke: 1px  #fff; color:black;font-size:90%">APELLIDO</label><br>
            <input type="text" name="apellido" placeholder="Escriba su Apellido" required><br>

            <label style="font-family:Gun;-webkit-text-stroke: 1px  #fff;color:black;font-size:90%">USUARIO</label><br>
            <input type="text" name="usuario" placeholder="Escriba su Usuario" required><br>

            <label style="font-family:Gun;-webkit-text-stroke: 1px  #fff;color:black;font-size:90%">CONTRASEÑA</label><br>
            <input type="password" name="contraseña" placeholder="Escriba su Contraseña" required><br><br>

            <label style="font-family:Gun;-webkit-text-stroke: 1px #fff; color:black;font-size:90%">DOCUMENTO</label><br>
            <input type="text" name="documento" placeholder="Escriba su Documento" required><br>

            <label style="font-family:Gun;-webkit-text-stroke: 1px #fff; color:black;font-size:90%">EMAIL</label><br>
            <input type="email" name="email" placeholder="Escriba su Email" required><br>

            <label style="font-family:Gun;-webkit-text-stroke: 1px #fff; color:black;font-size:90%">Planid</label><br>
            <input type="text" name="planid" placeholder="Escriba su plan id" required><br>

            <input type="submit" value="Registrarme" name="registro" >
        </fieldset>
    </form>
    </div>
    <img src="gifs/estrellas.gif" alt="" class="imagen">
</body>
</html>