<?php
if(!empty($_POST['registro'])){
    if (empty($_POST['nombre']) || empty($_POST['apellido']) || empty($_POST['username']) || empty($_POST['contraseña']) || empty($_POST['documento']) || empty($_POST['email']) || empty($_POST['planid'])) {
        echo "<div class='vacio'>Todos los campos son obligatorios.</div>";
    } else {
        $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
        $apellido = mysqli_real_escape_string($conexion, $_POST['apellido']);
        $username = mysqli_real_escape_string($conexion, $_POST['username']);
        $contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT); // Hashear la contraseña
        $documento = mysqli_real_escape_string($conexion, $_POST['documento']);
        $email = mysqli_real_escape_string($conexion, $_POST['email']);
        $planid = mysqli_real_escape_string($conexion, $_POST['planid']);

        // Validar el email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<div class='vacio'>El formato del email no es válido.</div>";
        } else {
            $sql = $conexion->query("INSERT INTO usuarios (nombre, apellido, username, contraseña, documento, email,planid) values('$nombre', '$apellido', '$username', '$contraseña', '$documento', '$email','$planid')");

            if ($sql) {
                header('Location: index.php?registro_exitoso=1');
            } else {
                echo "<div class='vacio' style='color:white'>Error al guardar los datos: " . mysqli_error($conexion) . "</div>";
            }
        }
    }
}
?>