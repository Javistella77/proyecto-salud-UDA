<?php
session_start();

// 1) Verificar sesión
if (!isset($_SESSION['usuarioid'])) {
  echo "No estás logueado. <a href='index.php'>Inicia sesión aquí</a>";
  exit();
}
$usuarioid = $_SESSION['usuarioid'];

// 2) Datos de conexión a MySQL en localhost (XAMPP)
$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";  // Vacío según tu configuración
$dbName     = "saludexpress";
$dbPort     = 3306;  // Puerto personalizado

// 3) Crear la conexión
$conexion = new mysqli($servername, $dbUsername, $dbPassword, $dbName, $dbPort);

// 4) Verificar errores de conexión
if ($conexion->connect_error) {
  die("❌ Conexión fallida: " . $conexion->connect_error);
}
$conexion->set_charset("utf8mb4");

// 5) Preparar y ejecutar la consulta
$stmt = $conexion->prepare("
    SELECT 
        u.username,
        u.nombre,
        u.apellido,
        u.documento,
        u.email,
        p.descripcion AS plan_descripcion
    FROM usuarios AS u
    INNER JOIN planes AS p
      ON u.planid = p.PLANID
    WHERE u.id = ?
");
$stmt->bind_param("i", $usuarioid);
$stmt->execute();
$resultado = $stmt->get_result();

// 6) Comprobar resultados
if ($resultado->num_rows !== 1) {
  die("❌ Usuario no encontrado.");
}
$usuario = $resultado->fetch_assoc();

// 7) Cerrar statement y conexión
$stmt->close();
$conexion->close();
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Mi Perfil</title>
  <link rel="stylesheet" href="Estilos/perfiles.css" />
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" />
</head>

<body>
  <!-- Navegación -->
  <div class="top-bar">
    <div class="top-bar-content">
      <span><img src="img/correo.png" class="icono"> correoelectronico@gmail.com</span>
      <span><img src="img/ubicacion.png" class="icono"> Ubicación de la empresa</span>
      <span><img src="img/llamada-telefonica.png" class="icono"> Teléfono</span>
    </div>
  </div>
  <nav class="main-nav">
    <div class="logo"><a href="inicio.php"><img src="imagenes/Logo_Nav.png" alt="Logo"></a></div>
    <ul class="nav-links">
      <li style="color:white; font-weight:bold; display:flex; align-items:center;">
        Bienvenido, <?= htmlspecialchars($_SESSION['usuario'], ENT_QUOTES, 'UTF-8') ?>
      </li>
      <li><a href="Perfil.php">Mi Perfil</a></li>
      <li><a href="Contacto.php">Contacto</a></li>
      <li><a href="logout.php">Cerrar sesión</a></li>
    </ul>
  </nav>

  <!-- Contenido Principal -->
  <main class="main-content">
    <section class="perfil-container">
      <h2>Perfil</h2>
      <div class="foto-perfil">
        <label for="uploadFoto">
          <img src="img/usuario.png" alt="Foto de perfil" id="imagenPerfil" />
          <input type="file" id="uploadFoto" accept="image/*" hidden>
        </label>
      </div>
      <div class="info-perfil" id="perfilInfo">
      

        <?php
        $tipo_usuario = isset($_SESSION['tipo_usuario']) ? strtolower($_SESSION['tipo_usuario']) : '';

        if ($tipo_usuario === 'medico'):
        ?>
        <p><strong>Nombre de usuario:</strong> <?= htmlspecialchars($usuario['username'],    ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Nombre:</strong> <?= htmlspecialchars($usuario['nombre'],      ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Apellido:</strong> <?= htmlspecialchars($usuario['apellido'],    ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>DNI:</strong> <?= htmlspecialchars($usuario['documento'],     ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($usuario['email'],        ENT_QUOTES, 'UTF-8') ?></p>
        <?php else: ?>
          <p><strong>Nombre de usuario:</strong> <?= htmlspecialchars($usuario['username'],    ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Nombre:</strong> <?= htmlspecialchars($usuario['nombre'],      ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Apellido:</strong> <?= htmlspecialchars($usuario['apellido'],    ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>DNI:</strong> <?= htmlspecialchars($usuario['documento'],     ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($usuario['email'],        ENT_QUOTES, 'UTF-8') ?></p>
        <p><strong>Plan:</strong> <?= htmlspecialchars($usuario['plan_descripcion'], ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>
      </div>

    </section>
  </main>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-column">
        <h5>Email</h5>
        <p>contacto@tusitio.com</p>
      </div>
      <div class="footer-column">
        <h5>Teléfono</h5>
        <p>212202</p>
      </div>
      <div class="footer-column">
        <h5>Ubicación</h5>
        <p>Calle Siempreviva 123</p>
      </div>
      <div class="footer-column logo-redes">
        <img src="imagenes/logo_footer.png" alt="Salud Expres" class="footer-logo" />
        <div class="redes-sociales">
          <a href="#"><img src="img/instagram.png" alt="Instagram"></a>
          <a href="#"><img src="img/Facebook.png" alt="Facebook"></a>
          <a href="#"><img src="img/linkedin.png" alt="LinkedIn"></a>
        </div>
      </div>
    </div>
    <div class="footer-copy">
      © 2025 SaludExpres. Todos los derechos reservados.
    </div>
  </footer>

  <script>
    // Cambio de imagen de perfil en cliente
    const inputFoto = document.getElementById('uploadFoto');
    const imagenPerfil = document.getElementById('imagenPerfil');
    inputFoto.addEventListener('change', function() {
      const archivo = this.files[0];
      if (archivo) {
        const lector = new FileReader();
        lector.onload = e => imagenPerfil.src = e.target.result;
        lector.readAsDataURL(archivo);
      }
    });
  </script>
  <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>