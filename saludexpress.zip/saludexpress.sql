-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2025 at 03:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saludexpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `medicos`
--

CREATE TABLE `medicos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `especialidad` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `fecha_disponible` date NOT NULL,
  `hora_disponible` time NOT NULL,
  `sede` varchar(100) NOT NULL,
  `tipo_turno` enum('presencial','virtual') NOT NULL,
  `estado` enum('disponible','no_disponible') DEFAULT 'disponible',
  `tipo_usuario` varchar(20) NOT NULL DEFAULT 'medico',
  `disponible` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicos`
--

INSERT INTO `medicos` (`id`, `nombre`, `apellido`, `especialidad`, `precio`, `fecha_disponible`, `hora_disponible`, `sede`, `tipo_turno`, `estado`, `tipo_usuario`, `disponible`) VALUES
(1, 'Javier', 'Stella', 'Cardiologia', 1.00, '2025-05-01', '09:00:00', 'Central', 'presencial', 'disponible', 'medico', 1),
(2, 'Laura', 'Ramírez', 'Psicología', 5000.00, '2025-06-01', '15:00:00', 'Central ', 'virtual', 'disponible', 'medico', 1),
(3, 'Daniel', 'Celedon', 'Neurocirujano', 2.00, '2025-05-01', '10:00:00', 'Central', 'presencial', 'disponible', 'medico', 1),
(4, 'Facundo', 'Ortiz', 'Cardiólogo', 1.00, '2025-08-01', '09:00:00', 'Central', 'virtual', 'disponible', 'medico', 1),
(5, 'Julio', 'Cobos', 'Medico Clinico', 1.00, '2025-06-01', '09:00:00', 'Central', 'presencial', 'disponible', 'medico', 1),
(6, 'Leonel', 'Hernandez', 'Oftanmologia', 1.00, '2025-05-01', '14:00:00', 'Central', 'presencial', 'disponible', 'medico', 1);

-- --------------------------------------------------------

--
-- Table structure for table `planes`
--

CREATE TABLE `planes` (
  `PLANID` int(11) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  `precio` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `planes`
--

INSERT INTO `planes` (`PLANID`, `descripcion`, `precio`) VALUES
(0, 'No dispone', 0),
(1, 'Bronce', 1),
(2, 'Plata', 1),
(3, 'Oro', 1),
(4, 'Diamente', 1),
(5, 'Black', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `contraseña` varchar(100) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `documento` int(1) NOT NULL,
  `email` varchar(50) NOT NULL,
  `planid` int(11) NOT NULL,
  `tipo_usuario` varchar(20) NOT NULL DEFAULT 'paciente',
  `disponible` tinyint(1) DEFAULT 1,
  `EsAdmin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `username`, `contraseña`, `nombre`, `apellido`, `documento`, `email`, `planid`, `tipo_usuario`, `disponible`, `EsAdmin`) VALUES
(1, 'Niejav', '1799Perejil', 'Javier', 'Nieva', 40069815, 'jstella2@vadigu.com', 2, 'paciente', 1, 0),
(3, 'dceledon', '1144ss', 'Daniel', 'Celedon', 12345678, 'usuariogmail@gmail.com', 3, 'paciente', 1, 0),
(6, 'estrella66', '111222333', 'javiere', 'Estrella', 12345678, 'pruebita@gmail.com', 3, 'paciente', 1, 0),
(7, 'jstella', '1234', 'javi', 'stella', 12345678, 'jstella@vadigu.com', 3, 'paciente', 1, 0),
(9, 'facu123', '112233', 'Facundo', 'Ortis', 12345678, 'Facuortiz@gmail.com', 0, 'paciente', 1, 0),
(10, 'Minecraft', '12345', 'Fadaja', 'Orcest', 78945612, 'fadaja@gmail.com', 0, 'paciente', 1, 0),
(11, 'ArmEsteban', '1122', 'Armando', 'Estebanquito', 88996655, 'Armando123@gmail.com', 0, 'paciente', 1, 0),
(12, 'PruebaUser1', '3344', 'Usuario', 'Prueba', 78945612, 'Prueba1@gmail.com', 0, 'paciente', 1, 0),
(13, 'Prueba2', '8899', 'Mauro', 'Fugazoto', 12345678, 'MauroFuga@gmail.com', 0, 'paciente', 1, 0),
(15, 'Fulljuego', '0123', 'Angel', 'Di maria', 99663322, 'Angelito@gmail.com', 0, 'paciente', 1, 0),
(16, 'Limonero', '1122', 'Limoncito', 'Lomaso', 1234567, 'Limon1@gmail.com', 3, 'paciente', 1, 0),
(17, 'Lechuga1', '9966', 'Pedrito', 'Messi', 10102020, 'Messi@gmail.com', 0, 'paciente', 1, 0),
(19, 'Yami', '1234', 'yamila', 'dominguez', 40907633, 'yami@gmail.com', 4, 'medico', 1, 0),
(21, 'Juaneton', '7894', 'Juanito', 'Horacio', 40069815, 'Horacio@gmail.com', 0, 'paciente', 1, 1),
(22, 'LIMONASO', '1234', 'Limoncito', 'Verdura', 40069815, 'Limon7@gmail.com', 0, 'medico', 1, 0),
(23, 'Jorginño', '$2y$10$VvpiEGd1FNYvY6uPhiJDPOoAl4Zs/.Cl5.AFNsBrXlPq3paCYMMsO', 'javito', 'leonel', 0, 'javier@gmail.com', 0, 'paciente', 1, 0),
(25, 'paciente1', '1234', 'pedro', 'perez', 40069815, 'pedroperez@gmail.com', 0, 'paciente', 1, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medicos`
--
ALTER TABLE `medicos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `planes`
--
ALTER TABLE `planes`
  ADD PRIMARY KEY (`PLANID`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_usuarios_planes` (`planid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medicos`
--
ALTER TABLE `medicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `FK_usuarios_planes` FOREIGN KEY (`planid`) REFERENCES `planes` (`PLANID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
